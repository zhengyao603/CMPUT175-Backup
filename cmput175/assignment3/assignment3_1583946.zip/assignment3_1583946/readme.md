first_name: Zhengyao
last_name: Zhang
id: 1583946
Collaborators(separated by semicolon): None
Comments(no newline allowed): All the python files need to be located in the same directory, import all the stuffs from main.py for testing function auto_play
